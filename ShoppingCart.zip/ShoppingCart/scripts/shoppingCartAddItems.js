
var products = {
	"product_data" : 
	[	  
		 {
		     "isPublished":"true",
		     "productName":"Apple iPhone X",
		     "productImage":"https://www.telstra.com.au/content/dam/tcom/persona=/mobile-phones/product-catalogue/iphone-x/iphone-x-silver-grid.png",
		     "price":"299"
		 },
		 {
		     "isPublished":"true",
		     "productName":"Apple iPhone 8",
		     "productImage":"https://www.telstra.com.au/content/dam/tcom/persona=/mobile-phones/product-catalogue/iphone-8/iphone-8-silver-grid.png",
		     "price":"100"
		 },
		 {
		     "isPublished":"false",
		     "productName":"Apple iPhone 8 Plus",
		     "productImage":"https://www.telstra.com.au/content/dam/tcom/persona=/mobile-phones/product-catalogue/iphone-8/iphone-8plus-space-grey-grid.png",
		     "price":"99"
		 },
		 {
		     "isPublished":"true",
		     "productName":"Samsung Galaxy S9",
		     "productImage":"https://www.telstra.com.au/content/dam/tcom/persona=/mobile-phones/product-catalogue/samsung-galaxy-s9/samsung-galaxy-s9-purpl=-front.png",
		     "price":"149"
		 },
		 {
		     "isPublished":"true",
		     "productName":"OPPO R15 Pro",
		     "productImage":"https://www.telstra.com.au/content/dam/tcom/persona=/mobile-phones/product-catalogue/oppo-r15-pro/oppo-r15-device-front.png",
		     "price":"199"
		 },
		 {
		     "isPublished":"true",
		     "productName":"Sony Xperia XA2",
		     "productImage":"https://www.telstra.com.au/content/dam/tcom/persona=/mobile-phones/product-catalogue/sony-xperia-xa2/sony_xperia_xa2_front_v1.=ng",
		     "price":"19"
		 }
	]
}

window.onload = populateProductList;

function populateProductList(){
	var productList = new Array();
	productList = products.product_data;
	var ulProduct = document.getElementById("product-list");
	var ulProductAdd = document.getElementById("product-list-add");
	var productName = "";
	var price = "";
	var isPublished = false;
	var i = 0;
    for(var j = 0 ; j < productList.length ; j++){
    	productName = products.product_data[j].productName;
    	isPublished = products.product_data[j].isPublished;
    	if(isPublished){
		    var liProduct = document.createElement("li");
		    liProduct.setAttribute('id','liProduct_'+i);
		    liProduct.appendChild(document.createTextNode(productName));
		    ulProduct.appendChild(liProduct);
		    
		    var liProductAdd = document.createElement("li");	
		    liProductAdd.setAttribute('id','addButton_'+i);
		    var productNameParam = "'" + productName + "'";	
		    var liProductIdParam = "'liProduct_" + i + "'";	
		    var liBtnIdParam = "'addButton_" + i + "'";	
		    liProductAdd.innerHTML='<input type="button" class="button" id="addButton_'+i+'" name="addButton_'+i+'" value="->" onClick="addItemToCart('+productNameParam+','+liProductIdParam+','+liBtnIdParam+');">';
		    ulProductAdd.appendChild(liProductAdd);	
		    i++;
    	}
    }
}

function addItemToCart(productName, liProductId, liBtnId){
	
	var ulProduct = document.getElementById("product-list");
	var liProduct = document.getElementById(liProductId);
	ulProduct.removeChild(liProduct);
	
	var ulProductAdd = document.getElementById("product-list-add");
	var liButton = document.getElementById(liBtnId);	
	ulProductAdd.removeChild(liButton);
    
	var cartSize = 0;
	var cartIndex = 0;
	
	cartSize = document.getElementById("shopping-cart").getElementsByTagName("li").length;
	cartSize = cartSize + 1;
	cartIndex = cartSize - 1;
	
	var ulCart = document.getElementById("shopping-cart");
	var liCart = document.createElement("li");
	liCart.setAttribute('id','liCart_'+cartIndex);
	liCart.appendChild(document.createTextNode(productName));
	ulCart.appendChild(liCart);	
	
	var ulCartRemove = document.getElementById("shopping-cart-remove");
	var liCartRemove = document.createElement("li");
	liCartRemove.setAttribute('id','removeButton_'+cartIndex);
    var productNameParam = "'" + productName + "'";	
    var liProductIdParam = "'liCart_" + cartIndex + "'";	
    var liBtnIdParam = "'removeButton_" + cartIndex + "'";	
    liCartRemove.innerHTML='<input type="button" class="button" id="removeButton_'+cartIndex+'" name="removeButton_'+cartIndex+'" value="<-" onClick="removeItemFromCart('+productNameParam+','+liProductIdParam+','+liBtnIdParam+');">';
    ulCartRemove.appendChild(liCartRemove);	 

}

function removeItemFromCart(productName, liProductId, liBtnId){
    var ulCart = document.getElementById("shopping-cart");
    var liCart = document.getElementById(liProductId);
    ulCart.removeChild(liCart);
    
    var ulCartRemove = document.getElementById("shopping-cart-remove");
	var liButton = document.getElementById(liBtnId);	
	ulCartRemove.removeChild(liButton);
	
	var cartSize = 0;
	var cartIndex = 0;
	
	if(document.getElementById("product-list").lastElementChild != null){
		var lastProductId = document.getElementById("product-list").lastElementChild.id;
		var lastChar = lastProductId.substr(lastProductId.length - 1);
		cartSize = parseInt(lastChar) + 1;
	}
	
	cartIndex = cartSize;
	
	var ulCart = document.getElementById("product-list");
	var liCart = document.createElement("li");
	liCart.setAttribute('id','liProduct_'+cartIndex);
	liCart.appendChild(document.createTextNode(productName));
	ulCart.appendChild(liCart);	
	
	var ulCartRemove = document.getElementById("product-list-add");
	var liCartRemove = document.createElement("li");
	liCartRemove.setAttribute('id','addButton_'+cartIndex);
    var productNameParam = "'" + productName + "'";	
    var liProductIdParam = "'liProduct_" + cartIndex + "'";	
    var liBtnIdParam = "'addButton_" + cartIndex + "'";	
    liCartRemove.innerHTML='<input type="button" class="button" id="addButton_'+cartIndex+'" name="addButton_'+cartIndex+'" value="->" onClick="addItemToCart('+productNameParam+','+liProductIdParam+','+liBtnIdParam+');">';
    ulCartRemove.appendChild(liCartRemove);	 
}
